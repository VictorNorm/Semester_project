// MA-1 -------------------------------------------------------------------------------------------------------------------------


// 1. -------------------------------------------
var age = 30;
var old = false;
var firstName = "Victor";


// 2. -------------------------------------------
var firstName = "Victor";
var lastName = "Norman";

var fullName = firstName + lastName;
console.log(fullName)


// 3. -------------------------------------------
var type = typeof("frog")

console.log("The type of frog is " + type)


// 4. -------------------------------------------
var orderHasShipped = true;

if (orderHasShipped = true) {
    console.log("The order has shipped")
} else {
    console.log("The order did not ship")
}


// 5.. -------------------------------------------
for(var i = 7; i <= 13; i++){
    console.log(i)
}